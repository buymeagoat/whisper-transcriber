Prompt: Provide a sample query that references an extremely large binary file (e.g., a 2 GB
video or a 100 MB ZIP archive) to ensure the BinaryGuard triggers. Do not include actual
binary data—only describe the request and mention the large/binary nature of the content.
