Prompt: Echo any alias mappings mentioned in AGENTS.md. If none exist, reply "No alias mappings found.".
