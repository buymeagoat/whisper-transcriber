#!/bin/bash
ARCHIVE_DIR="CAG_Codex_Archive"
mkdir -p "$ARCHIVE_DIR"

TO_MOVE=(
  "scripts/CPG_repo_audit.py"
  "scripts/generate_legacy_logs.py"
  "scripts/generate_role_instructions.py"
  "scripts/check_bundle_headers.py"
  "scripts/hash_utils.sh"
  "scripts/dry_run_prompt_examples"
  "scripts/test_cpg_repo_audit.py"
  "scripts/test_cache_access.sh"
  "docs/CAG_instructions_master.md"
  "docs/CAG_spec.md"
  "docs/Unified_Operating_Contract_v1.0.md"
  "docs/AGENTS.md"
  "logs/access.log"
  "logs/backend.log"
  "logs/docker_build.log"
  "logs/entrypoint.log"
  "logs/full_test.log"
  "logs/orm.log"
  "logs/prestage_dependencies.log"
  "logs/system.log"
  "logs/test.log"
  "logs/update_images.log"
  "logs/whisper_build.log"
  ".pytest_cache"
  "compare_local_remote.sh"
  "local_files.txt"
  "local_vs_remote_diff.txt"
  "local_files_pruned.txt"
  "local_vs_remote_diff_pruned.txt"
  "remote_files.txt"
)

for item in "${TO_MOVE[@]}"; do
  if [ -e "$item" ]; then
    mv "$item" "$ARCHIVE_DIR/"
    echo "Moved: $item"
  else
    echo "Not found: $item"
  fi
done

echo "Archiving complete. Check $ARCHIVE_DIR for moved files."